-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 17, 2019 at 04:26 AM
-- Server version: 10.4.7-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_data`
--
CREATE DATABASE IF NOT EXISTS `product_data` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `product_data`;

-- --------------------------------------------------------

--
-- Table structure for table `amazon_products_tb`
--

CREATE TABLE `amazon_products_tb` (
  `amazon_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_by` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Availability` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amazon_products_tb`
--

INSERT INTO `amazon_products_tb` (`amazon_url`, `product_name`, `product_by`, `amazon_product_price`, `Availability`) VALUES
('file:///home/srikar/code/scrapy/amazon/non-exist.html', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'Product unavailable', '<span id=\"availability\">Product unavailable</span>'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'Product unavailable', '<span id=\"availability\">Product unavailable</span>'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'Product unavailable', '<span id=\"availability\">Product unavailable</span>'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'Product unavailable', '<span id=\"availability\">Product unavailable</span>'),
('https://www.amazon.com/Xiaomi-Redmi-Note-64GB-Snapdragon/dp/B07Q26V49K', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Xiaomi Redmi Note 7, 64GB/4GB RAM, 6.30\'\' FHD+, Snapdragon 660, Blue - Unlocked Global Version, No Warranty\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'Xiaomi', '$182.00', '<div id=\"availability\" class=\"a-section a-spacing-base\">\n    \n    \n    <span class=\"a-size-medium a-color-success\">\n        \n            \n            In Stock.\n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>'),
('https://www.amazon.com/SanDisk-Ultra-Transfer-Speeds-s-SDCZ48-032G-UAM46/dp/B00KYK2AKO', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        SanDisk Ultra CZ48 32GB USB 3.0 Flash Drive Transfer Speeds Up To 100MB/s-SDCZ48-032G-UAM46\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'SanDisk', '$7.49', '<div id=\"availability\" class=\"a-section a-spacing-base\">\n    \n    \n    <span class=\"a-size-medium a-color-success\">\n        \n            \n            In Stock.\n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>'),
('https://www.amazon.com/House-Marley-EMJE041BA-Jamaica-Earphones/dp/B06XWC1WVM', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        House of Marley EMJE041BA Smile Jamaica Earphones Mic Brass\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'House of Marley', '$24.87', '<div id=\"availability\" class=\"a-section a-spacing-base\">\n    \n    \n    <span class=\"a-size-medium a-color-price\">\n        \n            Only 12 left in stock - order soon.\n            \n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>'),
('https://www.amazon.com/Western-Digital-Elements-Portable-External/dp/B06W55K9N6', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Western Digital 2TB Elements Portable External Hard Drive - USB 3.0 - WDBU6Y0020BBK-WESN\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'Western Digital', '$59.99', '<div id=\"availability\" class=\"a-section a-spacing-base\">\n    \n    \n    <span class=\"a-size-medium a-color-success\">\n        \n            \n            In Stock.\n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>'),
('https://www.amazon.com/Apple-MacBook-1-8GHz-dual-core-Intel/dp/B07211W6X2', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Apple MacBook Air (13-inch, 1.8GHz dual-core Intel Core i5, 8GB RAM, 128GB SSD) - Silver (Previous Model)\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'Apple', '$849.00', '<div id=\"availability\" class=\"a-section a-spacing-none\">\n    \n    \n    <span class=\"a-size-medium a-color-success\">\n        \n            \n            In Stock.\n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>'),
('https://www.amazon.com/Philips-Norelco-Multigroom-MG3750-Attachments/dp/B01MSHQ5IQ', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Philips Norelco Multigroom Series 3000, MG3750/50, Beard Face and Body Hair Trimmer for Men, 13 Attachments - NO BLADE OIL NEEDED\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', 'Philips Norelco', '$19.95', '<div id=\"availability\" class=\"a-section a-spacing-base\">\n    \n    \n    <span class=\"a-size-medium a-color-success\">\n        \n            \n            In Stock.\n        \n        \n    </span>\n    \n    \n    \n\n\n\n    \n    \n    \n</div>');

-- --------------------------------------------------------

--
-- Table structure for table `final_amazon`
--

CREATE TABLE `final_amazon` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `final_amazon`
--

INSERT INTO `final_amazon` (`shop_id`, `product_name`, `amazon_product_price`, `amazon_url`) VALUES
('01', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Xiaomi Redmi Note 7, 64GB/4GB RAM, 6.30\'\' FHD+, Snapdragon 660, Blue - Unlocked Global Version, No Warranty\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$182.00', 'https://www.amazon.com/Xiaomi-Redmi-Note-64GB-Snapdragon/dp/B07Q26V49K'),
('02', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Apple MacBook Air (13-inch, 1.8GHz dual-core Intel Core i5, 8GB RAM, 128GB SSD) - Silver (Previous Model)\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$849.00', 'https://www.amazon.com/Apple-MacBook-1-8GHz-dual-core-Intel/dp/B07211W6X2'),
('03', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Philips Norelco Multigroom Series 3000, MG3750/50, Beard Face and Body Hair Trimmer for Men, 13 Attachments - NO BLADE OIL NEEDED\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$19.95', 'https://www.amazon.com/Philips-Norelco-Multigroom-MG3750-Attachments/dp/B01MSHQ5IQ'),
('04', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        SanDisk Ultra CZ48 32GB USB 3.0 Flash Drive Transfer Speeds Up To 100MB/s-SDCZ48-032G-UAM46\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$7.49', 'https://www.amazon.com/SanDisk-Ultra-Transfer-Speeds-s-SDCZ48-032G-UAM46/dp/B00KYK2AKO'),
('05', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        Western Digital 2TB Elements Portable External Hard Drive - USB 3.0 - WDBU6Y0020BBK-WESN\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$59.99', 'https://www.amazon.com/Western-Digital-Elements-Portable-External/dp/B06W55K9N6'),
('06', '<span id=\"productTitle\" class=\"a-size-large\">\n                \n                    \n                    \n                \n\n                \n                    \n                    \n                        House of Marley EMJE041BA Smile Jamaica Earphones Mic Brass\n                    \n                \n\n                \n                    \n                    \n                \n            </span>', '$24.87', 'https://www.amazon.com/House-Marley-EMJE041BA-Jamaica-Earphones/dp/B06XWC1WVM'),
('07', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('08', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('09', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('10', '<span id=\"productTitle\">Product unavailable</span>', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html');

-- --------------------------------------------------------

--
-- Table structure for table `final_flip`
--

CREATE TABLE `final_flip` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `flipkart_product_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `final_flip`
--

INSERT INTO `final_flip` (`shop_id`, `flipkart_product_name`, `flipkart_product_price`, `flipkart_url`) VALUES
('01', 'Redmi Note 7 (Sapphire Blue, 64 GB)', '₹11,999', 'https://www.flipkart.com/redmi-note-7-sapphire-blue-64-gb/p/itmfdzvf8tptnezu?pid=MOBFDXZ3HJJZH3GG&lid=LSTMOBFDXZ3HJJZH3GGXELUJI&marketplace=FLIPKART&sattr[]=color&sattr[]=storage&sattr[]=ram&st=color'),
('03', 'Philips BT3211/15  Runtime: 60 min Trimmer for Men', '₹1,599', 'https://www.flipkart.com/philips-bt3211-15-runtime-60-min-trimmer-men/p/itmf5gbmn8zj6qky?pid=TMRF5GBHHDMHRVHH&lid=LSTTMRF5GBHHDMHRVHHJ8JPYB&marketplace=FLIPKART&srno=s_1_5&otracker=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&fm=SEARCH&iid=62a6e215-57df-4be6-975b-9e94bdee14e0.TMRF5GBHHDMHRVHH.SEARCH&ppt=sp&ppn=sp&qH=dc098acd2ef82486'),
('08', 'JioPhone Security Deposit', '₹1,500', 'https://www.flipkart.com/jiophone-security-deposit/p/itmfgybpq4qwmphq?pid=MOBFGYBP4SYKV6EH&srno=s_1_1&otracker=search&otracker1=search&lid=LSTMOBFGYBP4SYKV6EHS1ZG2J&fm=SEARCH&iid=eb32a0b5-67d1-4782-bf7f-98a9ae65ec68.MOBFGYBP4SYKV6EH.SEARCH&ppt=sp&ppn=sp&ssid=j11osf11bnwg7dhc1567412073611&qH=9015ceb8b394db61'),
('09', 'Logitech K120 Wired USB Desktop Keyboard', '₹482', 'https://www.flipkart.com/logitech-k120-wired-usb-desktop-keyboard/p/itmdrvfehwnuhhpf?pid=ACCCWPBZYS4HJ4UM&lid=LSTACCCWPBZYS4HJ4UMRQWJGT&marketplace=FLIPKART&srno=s_1_2&otracker=search&otracker1=search&fm=SEARCH&iid=7795cab6-4aea-4c30-a413-85e14119e2fb.ACCCWPBZYS4HJ4UM.SEARCH&ppt=sp&ppn=sp&ssid=8wi1ngf8vbz8fls01567411652407&qH=35cc36c27a5798c4'),
('05', 'WD Elements 2.5 inch 2 TB External Hard Drive', '₹5,699', 'https://www.flipkart.com/wd-elements-2-5-inch-2-tb-external-hard-drive/p/itmdp6ppvaxaqhch?pid=ACCDP6PZHMSGQUH6&srno=s_1_1&otracker=search&otracker1=search&lid=LSTACCDP6PZHMSGQUH6G6TUG7&fm=SEARCH&iid=1f507ca1-d2ff-4ce9-b931-54f9db759808.ACCDP6PZHMSGQUH6.SEARCH&ppt=sp&ppn=sp&ssid=78f03ni8jk3k4wzk1567413457762&qH=6344581485b3afd0'),
('04', 'SanDisk Ultra USB3.0 32 GB Pen Drive', '₹519', 'https://www.flipkart.com/sandisk-ultra-usb3-0-32-gb-pen-drive/p/itmewz3rsh3sgezt?pid=ACCDSYDFMHUKZX9H&lid=LSTACCDSYDFMHUKZX9HQ7DFZU&marketplace=FLIPKART&srno=s_1_8&otracker=search&otracker1=search&fm=SEARCH&iid=0537b8de-93fd-4776-8f46-8b5002963d06.ACCDSYDFMHUKZX9H.SEARCH&ppt=sp&ppn=sp&ssid=wwq0cnx8ohjivj0g1567413103403&qH=f6ba78bd04e69b9b'),
('06', 'House of Marley Smile Jamaica EM-JE041-SB Wired Headset with Mic', '₹1,099', 'https://www.flipkart.com/house-marley-smile-jamaica-em-je041-sb-wired-headset-mic/p/itmf3vhhfxg6unbj?pid=ACCEKZGTGHBEBGBF&lid=LSTACCEKZGTGHBEBGBF1RYFYV&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=e558d556-3ecc-4df5-b987-40a73606d622.ACCEKZGTGHBEBGBF.SEARCH&ppt=sp&ppn=sp&ssid=3ozutijpeytpjrpc1567414040520&qH=3e4cc11479f23562'),
('07', 'Beach IDP Slippers', '₹400', 'https://www.flipkart.com/puma-beach-idp-slippers/p/itmf3y8bz6c6vnhk?pid=SFFEHYHMCVXBRQAZ&lid=LSTSFFEHYHMCVXBRQAZTUQETM&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=organic&iid=fae1dcde-0c30-4799-80b9-159300c8552e.SFFEHYHMCVXBRQAZ.SEARCH&ssid=a74tomp5340000001567412625139&qH=94245a29c82f9c5d'),
('10', 'Logitech M331 Wireless Optical Mouse', '₹1,199', 'https://www.flipkart.com/logitech-m331-wireless-optical-mouse/p/itmf8u64w39rfh5q?pid=ACCF8TZFZMZJMYWC&lid=LSTACCF8TZFZMZJMYWC3PJDAT&marketplace=FLIPKART&srno=s_1_4&otracker=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&fm=organic&iid=22d5ea09-1ec0-4604-97ac-b0bb79c50ed6.ACCF8TZFZMZJMYWC.SEARCH&ssid=zis95t58tc0000001567408983354&qH=b5f36773f491c613'),
('02', 'Apple MacBook Air Core i5 5th Gen - (8 GB/128 GB SSD/Mac OS Sierra) MQD32HN/A A1466', '₹62,990', 'https://www.flipkart.com/apple-macbook-air-core-i5-5th-gen-8-gb-128-gb-ssd-mac-os-sierra-mqd32hn-a-a1466/p/itmevcpqqhf6azn3?pid=COMEVCPQBXBDFJ8C&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&lid=LSTCOMEVCPQBXBDFJ8C4V6AHG&fm=SEARCH&iid=622fb31b-c785-4f0c-b3cb-1d7b40338af1.COMEVCPQBXBDFJ8C.SEARCH&ppt=sp&ppn=sp&ssid=mtwla5lnqql7b9j41567332428852&qH=b61d62051d5441f9');

-- --------------------------------------------------------

--
-- Table structure for table `final_shopclues`
--

CREATE TABLE `final_shopclues` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shopclues_product_price` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shopclues_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `final_shopclues`
--

INSERT INTO `final_shopclues` (`shop_id`, `product_name`, `shopclues_product_price`, `shopclues_url`) VALUES
('01', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('02', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('05', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('06', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('09', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('10', 'Product unavailable', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('04', '\r\n                    SanDisk Ultra USB 3.0 16 GB Pen Drive(Black)                        \r\n                    ', 'Rs.399', 'https://www.shopclues.com/sandisk-ultra-usb-3.0-16-gb-pen-drive-black-1.html'),
('07', '\r\n                    Puma Mens Beach Black Blue Flip Flops                        \r\n                    ', '\r\n                        Rs.429', 'https://www.shopclues.com/puma-mens-beach-black-blue-flip-flops-126405161.html'),
('03', '\r\n                    Philips Series 3000 BT3215 FACE Stylers  Cordless Trimmer for Men  (Black)                        \r\n                    ', 'Rs.2,195', 'https://www.shopclues.com/philips-series-3000-bt3215-face-stylers-and-cordless-trimmer-for-men-black-142475376.html'),
('08', '\r\n                    JIO KEYPAD FEATURE PHONE BLACK, 512 MB RAM/4GB ROM WITH TORCH JIOPHONE                        \r\n                    ', 'Rs.1,485', 'https://www.shopclues.com/jio-keypad-feature-phone-black-512-mb-ram-4gb-rom-with-torch-jiophone-146063431.html');

-- --------------------------------------------------------

--
-- Table structure for table `final_snapdeal`
--

CREATE TABLE `final_snapdeal` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapdeal_product_price` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapdeal_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `final_snapdeal`
--

INSERT INTO `final_snapdeal` (`shop_id`, `product_name`, `snapdeal_product_price`, `snapdeal_url`) VALUES
('01', '\n   			MI Note 7 Pro (6GB RAM) ( 128GB , 6 GB ) Blue', '17699', 'https://www.snapdeal.com/product/mi-blue-note-7-pro/5764608142063249898'),
('02', '\n   			Apple MacBook Air MQD32HN/A Laptop 2017 (Core i5- 8GB RAM- 128GB SSD- 33.02cm(13)- Mac OSX Sierra)', '71928', 'https://www.snapdeal.com/product/apple-macbook-pro-mnqg2hna-notebook/679861261660'),
('03', '\n   			Philips Bt3211 Beard Trimmer ( Black )', '1675', 'https://www.snapdeal.com/product/philips-bt3211-beard-trimmer-black-/665836659735'),
('04', '\n   			SanDisk Ultra 32 GB USB 3.0 Pen Drive', '479', 'https://www.snapdeal.com/product/sandisk-cruzer-ultra-cz48-30/1840323529'),
('05', '\n   			WD Elements 2 TB External Hard Drive', '5199', 'https://www.snapdeal.com/product/wd-2tb-elements-usb-30/1457692'),
('06', 'Product unavailable ', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('07', 'Product unavailable ', 'Product unavailable', 'file:///home/srikar/code/scrapy/amazon/non-exist.html'),
('08', '\n   			JIO MOBILE (Black, 4G) - Security Deposit', '1600', 'https://www.snapdeal.com/product/jio-mobile-f90m-black/650530519162'),
('09', '\n   			Logitech B170 Wireless Optical Ambidextrous Mouse (Black)', '729', 'https://www.snapdeal.com/product/logitech-wireless-mouse-black/644558530655'),
('10', '\n   			Logitech K120 USB 2.0 Keyboard (Black) With Wire', '599', 'https://www.snapdeal.com/product/logitech-keyboard-k120ap/29382');

-- --------------------------------------------------------

--
-- Table structure for table `final_tab`
--

CREATE TABLE `final_tab` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `amazon_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_product_price` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `final_tab`
--

INSERT INTO `final_tab` (`shop_id`, `amazon_url`, `amazon_product_price`) VALUES
('01', 'https://www.amazon.com/Xiaomi-Redmi-Note-64GB-Snapdragon/dp/B07Q26V49K', '$182.00'),
('01', 'https://www.flipkart.com/redmi-note-7-sapphire-blue-64-gb/p/itmfdzvf8tptnezu?pid=MOBFDXZ3HJJZH3GG&lid=LSTMOBFDXZ3HJJZH3GGXELUJI&marketplace=FLIPKART&sattr[]=color&sattr[]=storage&sattr[]=ram&st=color', '₹11,999'),
('01', 'https://www.snapdeal.com/product/mi-blue-note-7-pro/5764608142063249898', '17699'),
('01', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('02', 'https://www.amazon.com/Apple-MacBook-1-8GHz-dual-core-Intel/dp/B07211W6X2', '$849.00'),
('02', 'https://www.flipkart.com/apple-macbook-air-core-i5-5th-gen-8-gb-128-gb-ssd-mac-os-sierra-mqd32hn-a-a1466/p/itmevcpqqhf6azn3?pid=COMEVCPQBXBDFJ8C&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&lid=LSTCOMEVCPQBXBDFJ8C4V6AHG&fm=SEARCH&iid=622fb31b-c785-4f0c-b3cb-1d7b40338af1.COMEVCPQBXBDFJ8C.SEARCH&ppt=sp&ppn=sp&ssid=mtwla5lnqql7b9j41567332428852&qH=b61d62051d5441f9', '₹62,990'),
('02', 'https://www.snapdeal.com/product/apple-macbook-pro-mnqg2hna-notebook/679861261660', '71928'),
('02', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('03', 'https://www.amazon.com/Philips-Norelco-Multigroom-MG3750-Attachments/dp/B01MSHQ5IQ', '$19.95'),
('03', 'https://www.flipkart.com/philips-bt3211-15-runtime-60-min-trimmer-men/p/itmf5gbmn8zj6qky?pid=TMRF5GBHHDMHRVHH&lid=LSTTMRF5GBHHDMHRVHHJ8JPYB&marketplace=FLIPKART&srno=s_1_5&otracker=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&fm=SEARCH&iid=62a6e215-57df-4be6-975b-9e94bdee14e0.TMRF5GBHHDMHRVHH.SEARCH&ppt=sp&ppn=sp&qH=dc098acd2ef82486', '₹1,599'),
('03', 'https://www.snapdeal.com/product/philips-bt3211-beard-trimmer-black-/665836659735', '1675'),
('03', 'https://www.shopclues.com/philips-series-3000-bt3215-face-stylers-and-cordless-trimmer-for-men-black-142475376.html', 'Rs.2,195'),
('04', 'https://www.amazon.com/SanDisk-Ultra-Transfer-Speeds-s-SDCZ48-032G-UAM46/dp/B00KYK2AKO', '$7.49'),
('04', 'https://www.flipkart.com/sandisk-ultra-usb3-0-32-gb-pen-drive/p/itmewz3rsh3sgezt?pid=ACCDSYDFMHUKZX9H&lid=LSTACCDSYDFMHUKZX9HQ7DFZU&marketplace=FLIPKART&srno=s_1_8&otracker=search&otracker1=search&fm=SEARCH&iid=0537b8de-93fd-4776-8f46-8b5002963d06.ACCDSYDFMHUKZX9H.SEARCH&ppt=sp&ppn=sp&ssid=wwq0cnx8ohjivj0g1567413103403&qH=f6ba78bd04e69b9b', '₹519'),
('04', 'https://www.snapdeal.com/product/sandisk-cruzer-ultra-cz48-30/1840323529', '479'),
('04', 'https://www.shopclues.com/sandisk-ultra-usb-3.0-16-gb-pen-drive-black-1.html', 'Rs.399'),
('05', 'https://www.amazon.com/Western-Digital-Elements-Portable-External/dp/B06W55K9N6', '$59.99'),
('05', 'https://www.flipkart.com/wd-elements-2-5-inch-2-tb-external-hard-drive/p/itmdp6ppvaxaqhch?pid=ACCDP6PZHMSGQUH6&srno=s_1_1&otracker=search&otracker1=search&lid=LSTACCDP6PZHMSGQUH6G6TUG7&fm=SEARCH&iid=1f507ca1-d2ff-4ce9-b931-54f9db759808.ACCDP6PZHMSGQUH6.SEARCH&ppt=sp&ppn=sp&ssid=78f03ni8jk3k4wzk1567413457762&qH=6344581485b3afd0', '₹5,699'),
('05', 'https://www.snapdeal.com/product/wd-2tb-elements-usb-30/1457692', '5199'),
('05', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('06', 'https://www.amazon.com/House-Marley-EMJE041BA-Jamaica-Earphones/dp/B06XWC1WVM', '$24.87'),
('06', 'https://www.flipkart.com/house-marley-smile-jamaica-em-je041-sb-wired-headset-mic/p/itmf3vhhfxg6unbj?pid=ACCEKZGTGHBEBGBF&lid=LSTACCEKZGTGHBEBGBF1RYFYV&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=e558d556-3ecc-4df5-b987-40a73606d622.ACCEKZGTGHBEBGBF.SEARCH&ppt=sp&ppn=sp&ssid=3ozutijpeytpjrpc1567414040520&qH=3e4cc11479f23562', '₹1,099'),
('06', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('07', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('07', 'https://www.flipkart.com/puma-beach-idp-slippers/p/itmf3y8bz6c6vnhk?pid=SFFEHYHMCVXBRQAZ&lid=LSTSFFEHYHMCVXBRQAZTUQETM&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=organic&iid=fae1dcde-0c30-4799-80b9-159300c8552e.SFFEHYHMCVXBRQAZ.SEARCH&ssid=a74tomp5340000001567412625139&qH=94245a29c82f9c5d', '₹400'),
('07', 'https://www.shopclues.com/puma-mens-beach-black-blue-flip-flops-126405161.html', '\r\n                        Rs.429'),
('08', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('08', 'https://www.flipkart.com/jiophone-security-deposit/p/itmfgybpq4qwmphq?pid=MOBFGYBP4SYKV6EH&srno=s_1_1&otracker=search&otracker1=search&lid=LSTMOBFGYBP4SYKV6EHS1ZG2J&fm=SEARCH&iid=eb32a0b5-67d1-4782-bf7f-98a9ae65ec68.MOBFGYBP4SYKV6EH.SEARCH&ppt=sp&ppn=sp&ssid=j11osf11bnwg7dhc1567412073611&qH=9015ceb8b394db61', '₹1,500'),
('08', 'https://www.snapdeal.com/product/jio-mobile-f90m-black/650530519162', '1600'),
('08', 'https://www.shopclues.com/jio-keypad-feature-phone-black-512-mb-ram-4gb-rom-with-torch-jiophone-146063431.html', 'Rs.1,485'),
('09', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('09', 'https://www.flipkart.com/logitech-k120-wired-usb-desktop-keyboard/p/itmdrvfehwnuhhpf?pid=ACCCWPBZYS4HJ4UM&lid=LSTACCCWPBZYS4HJ4UMRQWJGT&marketplace=FLIPKART&srno=s_1_2&otracker=search&otracker1=search&fm=SEARCH&iid=7795cab6-4aea-4c30-a413-85e14119e2fb.ACCCWPBZYS4HJ4UM.SEARCH&ppt=sp&ppn=sp&ssid=8wi1ngf8vbz8fls01567411652407&qH=35cc36c27a5798c4', '₹482'),
('09', 'https://www.snapdeal.com/product/logitech-wireless-mouse-black/644558530655', '729'),
('10', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable'),
('10', 'https://www.flipkart.com/logitech-m331-wireless-optical-mouse/p/itmf8u64w39rfh5q?pid=ACCF8TZFZMZJMYWC&lid=LSTACCF8TZFZMZJMYWC3PJDAT&marketplace=FLIPKART&srno=s_1_4&otracker=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&fm=organic&iid=22d5ea09-1ec0-4604-97ac-b0bb79c50ed6.ACCF8TZFZMZJMYWC.SEARCH&ssid=zis95t58tc0000001567408983354&qH=b5f36773f491c613', '₹1,199'),
('10', 'https://www.snapdeal.com/product/logitech-keyboard-k120ap/29382', '599');

-- --------------------------------------------------------

--
-- Table structure for table `flipkart_tb`
--

CREATE TABLE `flipkart_tb` (
  `flipkart_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart_product_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flipkart_tb`
--

INSERT INTO `flipkart_tb` (`flipkart_url`, `flipkart_product_name`, `flipkart_product_price`) VALUES
('https://www.flipkart.com/redmi-note-7-sapphire-blue-64-gb/p/itmfdzvf8tptnezu?pid=MOBFDXZ3HJJZH3GG&lid=LSTMOBFDXZ3HJJZH3GGXELUJI&marketplace=FLIPKART&sattr[]=color&sattr[]=storage&sattr[]=ram&st=color', 'Redmi Note 7 (Sapphire Blue, 64 GB)', '₹11,999'),
('https://www.flipkart.com/philips-bt3211-15-runtime-60-min-trimmer-men/p/itmf5gbmn8zj6qky?pid=TMRF5GBHHDMHRVHH&lid=LSTTMRF5GBHHDMHRVHHJ8JPYB&marketplace=FLIPKART&srno=s_1_5&otracker=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&fm=SEARCH&iid=62a6e215-57df-4be6-975b-9e94bdee14e0.TMRF5GBHHDMHRVHH.SEARCH&ppt=sp&ppn=sp&qH=dc098acd2ef82486', 'Philips BT3211/15  Runtime: 60 min Trimmer for Men', '₹1,599'),
('https://www.flipkart.com/jiophone-security-deposit/p/itmfgybpq4qwmphq?pid=MOBFGYBP4SYKV6EH&srno=s_1_1&otracker=search&otracker1=search&lid=LSTMOBFGYBP4SYKV6EHS1ZG2J&fm=SEARCH&iid=eb32a0b5-67d1-4782-bf7f-98a9ae65ec68.MOBFGYBP4SYKV6EH.SEARCH&ppt=sp&ppn=sp&ssid=j11osf11bnwg7dhc1567412073611&qH=9015ceb8b394db61', 'JioPhone Security Deposit', '₹1,500'),
('https://www.flipkart.com/logitech-k120-wired-usb-desktop-keyboard/p/itmdrvfehwnuhhpf?pid=ACCCWPBZYS4HJ4UM&lid=LSTACCCWPBZYS4HJ4UMRQWJGT&marketplace=FLIPKART&srno=s_1_2&otracker=search&otracker1=search&fm=SEARCH&iid=7795cab6-4aea-4c30-a413-85e14119e2fb.ACCCWPBZYS4HJ4UM.SEARCH&ppt=sp&ppn=sp&ssid=8wi1ngf8vbz8fls01567411652407&qH=35cc36c27a5798c4', 'Logitech K120 Wired USB Desktop Keyboard', '₹482'),
('https://www.flipkart.com/wd-elements-2-5-inch-2-tb-external-hard-drive/p/itmdp6ppvaxaqhch?pid=ACCDP6PZHMSGQUH6&srno=s_1_1&otracker=search&otracker1=search&lid=LSTACCDP6PZHMSGQUH6G6TUG7&fm=SEARCH&iid=1f507ca1-d2ff-4ce9-b931-54f9db759808.ACCDP6PZHMSGQUH6.SEARCH&ppt=sp&ppn=sp&ssid=78f03ni8jk3k4wzk1567413457762&qH=6344581485b3afd0', 'WD Elements 2.5 inch 2 TB External Hard Drive', '₹5,699'),
('https://www.flipkart.com/sandisk-ultra-usb3-0-32-gb-pen-drive/p/itmewz3rsh3sgezt?pid=ACCDSYDFMHUKZX9H&lid=LSTACCDSYDFMHUKZX9HQ7DFZU&marketplace=FLIPKART&srno=s_1_8&otracker=search&otracker1=search&fm=SEARCH&iid=0537b8de-93fd-4776-8f46-8b5002963d06.ACCDSYDFMHUKZX9H.SEARCH&ppt=sp&ppn=sp&ssid=wwq0cnx8ohjivj0g1567413103403&qH=f6ba78bd04e69b9b', 'SanDisk Ultra USB3.0 32 GB Pen Drive', '₹519'),
('https://www.flipkart.com/house-marley-smile-jamaica-em-je041-sb-wired-headset-mic/p/itmf3vhhfxg6unbj?pid=ACCEKZGTGHBEBGBF&lid=LSTACCEKZGTGHBEBGBF1RYFYV&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=e558d556-3ecc-4df5-b987-40a73606d622.ACCEKZGTGHBEBGBF.SEARCH&ppt=sp&ppn=sp&ssid=3ozutijpeytpjrpc1567414040520&qH=3e4cc11479f23562', 'House of Marley Smile Jamaica EM-JE041-SB Wired Headset with Mic', '₹1,099'),
('https://www.flipkart.com/puma-beach-idp-slippers/p/itmf3y8bz6c6vnhk?pid=SFFEHYHMCVXBRQAZ&lid=LSTSFFEHYHMCVXBRQAZTUQETM&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=organic&iid=fae1dcde-0c30-4799-80b9-159300c8552e.SFFEHYHMCVXBRQAZ.SEARCH&ssid=a74tomp5340000001567412625139&qH=94245a29c82f9c5d', 'Beach IDP Slippers', '₹400'),
('https://www.flipkart.com/logitech-m331-wireless-optical-mouse/p/itmf8u64w39rfh5q?pid=ACCF8TZFZMZJMYWC&lid=LSTACCF8TZFZMZJMYWC3PJDAT&marketplace=FLIPKART&srno=s_1_4&otracker=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&fm=organic&iid=22d5ea09-1ec0-4604-97ac-b0bb79c50ed6.ACCF8TZFZMZJMYWC.SEARCH&ssid=zis95t58tc0000001567408983354&qH=b5f36773f491c613', 'Logitech M331 Wireless Optical Mouse', '₹1,199'),
('https://www.flipkart.com/apple-macbook-air-core-i5-5th-gen-8-gb-128-gb-ssd-mac-os-sierra-mqd32hn-a-a1466/p/itmevcpqqhf6azn3?pid=COMEVCPQBXBDFJ8C&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&lid=LSTCOMEVCPQBXBDFJ8C4V6AHG&fm=SEARCH&iid=622fb31b-c785-4f0c-b3cb-1d7b40338af1.COMEVCPQBXBDFJ8C.SEARCH&ppt=sp&ppn=sp&ssid=mtwla5lnqql7b9j41567332428852&qH=b61d62051d5441f9', 'Apple MacBook Air Core i5 5th Gen - (8 GB/128 GB SSD/Mac OS Sierra) MQD32HN/A A1466', '₹62,990');

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amazon` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapdeal` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shopclues` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_product_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`shop_id`, `amazon`, `flipkart`, `snapdeal`, `shopclues`, `shop_product_name`) VALUES
('01', 'https://www.amazon.com/Xiaomi-Redmi-Note-64GB-Snapdragon/dp/B07Q26V49K', 'https://www.flipkart.com/redmi-note-7-sapphire-blue-64-gb/p/itmfdzvf8tptnezu?pid=MOBFDXZ3HJJZH3GG&lid=LSTMOBFDXZ3HJJZH3GGXELUJI&marketplace=FLIPKART&sattr[]=color&sattr[]=storage&sattr[]=ram&st=color', 'https://www.snapdeal.com/product/mi-blue-note-7-pro/5764608142063249898', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Xiaomi redmi note 7'),
('02', 'https://www.amazon.com/Apple-MacBook-1-8GHz-dual-core-Intel/dp/B07211W6X2', 'https://www.flipkart.com/apple-macbook-air-core-i5-5th-gen-8-gb-128-gb-ssd-mac-os-sierra-mqd32hn-a-a1466/p/itmevcpqqhf6azn3?pid=COMEVCPQBXBDFJ8C&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_6_na_na_pr&lid=LSTCOMEVCPQBXBDFJ8C4V6AHG&fm=SEARCH&iid=622fb31b-c785-4f0c-b3cb-1d7b40338af1.COMEVCPQBXBDFJ8C.SEARCH&ppt=sp&ppn=sp&ssid=mtwla5lnqql7b9j41567332428852&qH=b61d62051d5441f9', 'https://www.snapdeal.com/product/apple-macbook-pro-mnqg2hna-notebook/679861261660', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Apple macbook 1-8 GHZ i5'),
('03', 'https://www.amazon.com/Philips-Norelco-Multigroom-MG3750-Attachments/dp/B01MSHQ5IQ', 'https://www.flipkart.com/philips-bt3211-15-runtime-60-min-trimmer-men/p/itmf5gbmn8zj6qky?pid=TMRF5GBHHDMHRVHH&lid=LSTTMRF5GBHHDMHRVHHJ8JPYB&marketplace=FLIPKART&srno=s_1_5&otracker=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_15_na_na_pr&fm=SEARCH&iid=62a6e215-57df-4be6-975b-9e94bdee14e0.TMRF5GBHHDMHRVHH.SEARCH&ppt=sp&ppn=sp&qH=dc098acd2ef82486', 'https://www.snapdeal.com/product/philips-bt3211-beard-trimmer-black-/665836659735', 'https://www.shopclues.com/philips-series-3000-bt3215-face-stylers-and-cordless-trimmer-for-men-black-142475376.html', 'Philips Trimmer'),
('04', 'https://www.amazon.com/SanDisk-Ultra-Transfer-Speeds-s-SDCZ48-032G-UAM46/dp/B00KYK2AKO', 'https://www.flipkart.com/sandisk-ultra-usb3-0-32-gb-pen-drive/p/itmewz3rsh3sgezt?pid=ACCDSYDFMHUKZX9H&lid=LSTACCDSYDFMHUKZX9HQ7DFZU&marketplace=FLIPKART&srno=s_1_8&otracker=search&otracker1=search&fm=SEARCH&iid=0537b8de-93fd-4776-8f46-8b5002963d06.ACCDSYDFMHUKZX9H.SEARCH&ppt=sp&ppn=sp&ssid=wwq0cnx8ohjivj0g1567413103403&qH=f6ba78bd04e69b9b', 'https://www.snapdeal.com/product/sandisk-cruzer-ultra-cz48-30/1840323529', 'https://www.shopclues.com/sandisk-ultra-usb-3.0-16-gb-pen-drive-black-1.html', 'Sandisk ultra 32GB'),
('05', 'https://www.amazon.com/Western-Digital-Elements-Portable-External/dp/B06W55K9N6', 'https://www.flipkart.com/wd-elements-2-5-inch-2-tb-external-hard-drive/p/itmdp6ppvaxaqhch?pid=ACCDP6PZHMSGQUH6&srno=s_1_1&otracker=search&otracker1=search&lid=LSTACCDP6PZHMSGQUH6G6TUG7&fm=SEARCH&iid=1f507ca1-d2ff-4ce9-b931-54f9db759808.ACCDP6PZHMSGQUH6.SEARCH&ppt=sp&ppn=sp&ssid=78f03ni8jk3k4wzk1567413457762&qH=6344581485b3afd0', 'https://www.snapdeal.com/product/wd-2tb-elements-usb-30/1457692', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'WD 2TB'),
('06', 'https://www.amazon.com/House-Marley-EMJE041BA-Jamaica-Earphones/dp/B06XWC1WVM', 'https://www.flipkart.com/house-marley-smile-jamaica-em-je041-sb-wired-headset-mic/p/itmf3vhhfxg6unbj?pid=ACCEKZGTGHBEBGBF&lid=LSTACCEKZGTGHBEBGBF1RYFYV&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=e558d556-3ecc-4df5-b987-40a73606d622.ACCEKZGTGHBEBGBF.SEARCH&ppt=sp&ppn=sp&ssid=3ozutijpeytpjrpc1567414040520&qH=3e4cc11479f23562', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'House-Marley jamaica'),
('07', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'https://www.flipkart.com/puma-beach-idp-slippers/p/itmf3y8bz6c6vnhk?pid=SFFEHYHMCVXBRQAZ&lid=LSTSFFEHYHMCVXBRQAZTUQETM&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=organic&iid=fae1dcde-0c30-4799-80b9-159300c8552e.SFFEHYHMCVXBRQAZ.SEARCH&ssid=a74tomp5340000001567412625139&qH=94245a29c82f9c5d', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'https://www.shopclues.com/puma-mens-beach-black-blue-flip-flops-126405161.html', 'Puma beach idp sneakers'),
('08', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'https://www.flipkart.com/jiophone-security-deposit/p/itmfgybpq4qwmphq?pid=MOBFGYBP4SYKV6EH&srno=s_1_1&otracker=search&otracker1=search&lid=LSTMOBFGYBP4SYKV6EHS1ZG2J&fm=SEARCH&iid=eb32a0b5-67d1-4782-bf7f-98a9ae65ec68.MOBFGYBP4SYKV6EH.SEARCH&ppt=sp&ppn=sp&ssid=j11osf11bnwg7dhc1567412073611&qH=9015ceb8b394db61', 'https://www.snapdeal.com/product/jio-mobile-f90m-black/650530519162', 'https://www.shopclues.com/jio-keypad-feature-phone-black-512-mb-ram-4gb-rom-with-torch-jiophone-146063431.html', 'Jio Phone-security deposit'),
('09', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'https://www.flipkart.com/logitech-k120-wired-usb-desktop-keyboard/p/itmdrvfehwnuhhpf?pid=ACCCWPBZYS4HJ4UM&lid=LSTACCCWPBZYS4HJ4UMRQWJGT&marketplace=FLIPKART&srno=s_1_2&otracker=search&otracker1=search&fm=SEARCH&iid=7795cab6-4aea-4c30-a413-85e14119e2fb.ACCCWPBZYS4HJ4UM.SEARCH&ppt=sp&ppn=sp&ssid=8wi1ngf8vbz8fls01567411652407&qH=35cc36c27a5798c4', 'https://www.snapdeal.com/product/logitech-wireless-mouse-black/644558530655', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Logitech keyboard'),
('10', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'https://www.flipkart.com/logitech-m331-wireless-optical-mouse/p/itmf8u64w39rfh5q?pid=ACCF8TZFZMZJMYWC&lid=LSTACCF8TZFZMZJMYWC3PJDAT&marketplace=FLIPKART&srno=s_1_4&otracker=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&otracker1=AS_QueryStore_OrganicAutoSuggest_0_13_na_na_pr&fm=organic&iid=22d5ea09-1ec0-4604-97ac-b0bb79c50ed6.ACCF8TZFZMZJMYWC.SEARCH&ssid=zis95t58tc0000001567408983354&qH=b5f36773f491c613', 'https://www.snapdeal.com/product/logitech-keyboard-k120ap/29382', 'file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Logitech wireless mouse');

-- --------------------------------------------------------

--
-- Table structure for table `price_details`
--

CREATE TABLE `price_details` (
  `shop_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_product_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapdeal_product_price` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shopclues_product_price` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flipkart_product_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `price_details`
--

INSERT INTO `price_details` (`shop_id`, `shop_product_name`, `amazon_product_price`, `snapdeal_product_price`, `shopclues_product_price`, `flipkart_product_price`) VALUES
('01', 'Xiaomi redmi note 7', '$182.00', '17699', 'Product unavailable', '₹11,999'),
('02', 'Apple macbook 1-8 GHZ i5', '$849.00', '71928', 'Product unavailable', '₹62,990'),
('03', 'Philips Trimmer', '$19.95', '1675', 'Rs.2,195', '₹1,599'),
('04', 'Sandisk ultra 32GB', '$7.49', '479', 'Rs.399', '₹519'),
('05', 'WD 2TB', '$59.99', '5199', 'Product unavailable', '₹5,699'),
('06', 'House-Marley jamaica', '$24.87', 'Product unavailable', 'Product unavailable', '₹1,099'),
('07', 'Puma beach idp sneakers', 'Product unavailable', 'Product unavailable', '\r\n                        Rs.429', '₹400'),
('08', 'Jio Phone-security deposit', 'Product unavailable', '1600', 'Rs.1,485', '₹1,500'),
('09', 'Logitech keyboard', 'Product unavailable', '729', 'Product unavailable', '₹482'),
('10', 'Logitech wireless mouse', 'Product unavailable', '599', 'Product unavailable', '₹1,199');

-- --------------------------------------------------------

--
-- Table structure for table `shopclue_tb`
--

CREATE TABLE `shopclue_tb` (
  `shopclues_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shopclues_product_price` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopclue_tb`
--

INSERT INTO `shopclue_tb` (`shopclues_url`, `product_name`, `shopclues_product_price`) VALUES
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable', 'Product unavailable'),
('https://www.shopclues.com/sandisk-ultra-usb-3.0-16-gb-pen-drive-black-1.html', '\r\n                    SanDisk Ultra USB 3.0 16 GB Pen Drive(Black)                        \r\n                    ', 'Rs.399'),
('https://www.shopclues.com/puma-mens-beach-black-blue-flip-flops-126405161.html', '\r\n                    Puma Mens Beach Black Blue Flip Flops                        \r\n                    ', '\r\n                        Rs.429'),
('https://www.shopclues.com/philips-series-3000-bt3215-face-stylers-and-cordless-trimmer-for-men-black-142475376.html', '\r\n                    Philips Series 3000 BT3215 FACE Stylers  Cordless Trimmer for Men  (Black)                        \r\n                    ', 'Rs.2,195'),
('https://www.shopclues.com/jio-keypad-feature-phone-black-512-mb-ram-4gb-rom-with-torch-jiophone-146063431.html', '\r\n                    JIO KEYPAD FEATURE PHONE BLACK, 512 MB RAM/4GB ROM WITH TORCH JIOPHONE                        \r\n                    ', 'Rs.1,485');

-- --------------------------------------------------------

--
-- Table structure for table `snapdeal_tb`
--

CREATE TABLE `snapdeal_tb` (
  `snapdeal_url` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapdeal_product_price` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `snapdeal_tb`
--

INSERT INTO `snapdeal_tb` (`snapdeal_url`, `product_name`, `snapdeal_product_price`) VALUES
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable ', 'Product unavailable'),
('file:///home/srikar/code/scrapy/amazon/non-exist.html', 'Product unavailable ', 'Product unavailable'),
('https://www.snapdeal.com/product/mi-blue-note-7-pro/5764608142063249898', '\n   			MI Note 7 Pro (6GB RAM) ( 128GB , 6 GB ) Blue', '17699'),
('https://www.snapdeal.com/product/apple-macbook-pro-mnqg2hna-notebook/679861261660', '\n   			Apple MacBook Air MQD32HN/A Laptop 2017 (Core i5- 8GB RAM- 128GB SSD- 33.02cm(13)- Mac OSX Sierra)', '71928'),
('https://www.snapdeal.com/product/logitech-keyboard-k120ap/29382', '\n   			Logitech K120 USB 2.0 Keyboard (Black) With Wire', '599'),
('https://www.snapdeal.com/product/sandisk-cruzer-ultra-cz48-30/1840323529', '\n   			SanDisk Ultra 32 GB USB 3.0 Pen Drive', '479'),
('https://www.snapdeal.com/product/philips-bt3211-beard-trimmer-black-/665836659735', '\n   			Philips Bt3211 Beard Trimmer ( Black )', '1675'),
('https://www.snapdeal.com/product/logitech-wireless-mouse-black/644558530655', '\n   			Logitech B170 Wireless Optical Ambidextrous Mouse (Black)', '729'),
('https://www.snapdeal.com/product/wd-2tb-elements-usb-30/1457692', '\n   			WD Elements 2 TB External Hard Drive', '5199'),
('https://www.snapdeal.com/product/jio-mobile-f90m-black/650530519162', '\n   			JIO MOBILE (Black, 4G) - Security Deposit', '1600');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`shop_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
